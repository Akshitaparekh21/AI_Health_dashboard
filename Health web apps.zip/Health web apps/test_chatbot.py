from chatbot import ai_chatbot

response = ai_chatbot("What are the symptoms of diabetes?")
print("Gemini Response:", response)
